# 导入客户端库
# 初始化客户端库
# 新建节点对象
# spin循环节点
# 关闭客户端库
import rclpy
from rclpy.node import Node

class WriteNode(Node):
    def __init__(self,name):
        super().__init__(name)
        self.get_logger().info("大家好，我是作家{self.name}")

 
def main(args = None):
    rclpy.init(args = args)
    li4_node = WriteNode("li4")
    rclpy.spin(li4_node)
    rclpy.shutdown