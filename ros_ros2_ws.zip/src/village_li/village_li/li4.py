# 导入客户端库
# 初始化客户端库
# 新建节点对象
# spin循环节点
# 关闭客户端库
import rclpy
from rclpy.node import Node
from std_msgs.msg import String,UInt32
"""
导入消息类型
声明并创建发布者
编写发布逻辑发布数据
"""
class WriteNode(Node):
    def __init__(self,name):
        super().__init__(name)
        self.name = name
        self.get_logger().info(f"大家好，我是作家{self.name}")
        self.pub_novel = self.create_publisher(String,"sexy_girl",10)

        self.count = 0
        self.timer_period = 5
        self.timer = self.create_timer(self.timer_period,self.timer_callback)

        self.account = 80
        self.sub_money = self.create_subscription(UInt32,"sexy_girl_money",self.recv_money_callback,10)

    def timer_callback(self):
        msg = String()
        msg.data = "第%d回:潋滟湖%d次偶遇胡艳娘"%(self.count,self.account)
        self.pub_novel.publish(msg)
        self.get_logger().info("发布了一个章节小说,内容是%s"%msg.data)
        self.count += 1
    
    def recv_money_callback(self,money_msg):
        money = money_msg
        self.account += money.data
        self.get_logger().info("收到了%d的稿费,现在账户里有%d的钱"%(money.data,self.account))

def main(args = None):
    rclpy.init(args = args)
    li4_node = WriteNode("li4")
    rclpy.spin(li4_node)
    rclpy.shutdown()