#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>
#include <std_msgs/msg/u_int32.hpp>
#include <memory>
#include <sstream>

using std::placeholders::_1;

class SingleDogNode : public rclcpp::Node
{
private:
    // 订阅小说
    rclcpp::Subscription<std_msgs::msg::String>::SharedPtr sub_novel;
    // 发布稿费
    rclcpp::Publisher<std_msgs::msg::UInt32>::SharedPtr pub_money;

    void novel_callback(const std_msgs::msg::String::SharedPtr novels)
    {
        std_msgs::msg::UInt32 money;
        money.data = 10;
        pub_money->publish(money);
        RCLCPP_INFO(this->get_logger(), "朕已阅%s", novels->data.c_str());
    }

public:
    SingleDogNode(std::string name) : Node(name)
    {
        RCLCPP_INFO(this->get_logger(), "大家好我是单身狗%s", name.c_str());
        sub_novel = this->create_subscription<std_msgs::msg::String>(
            "sexy_girl",
            10,
            std::bind(&SingleDogNode::novel_callback, this, _1)
        );
        pub_money = this->create_publisher<std_msgs::msg::UInt32>("sexy_girl_money", 10);
    }
};

int main(int argc, char ** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<SingleDogNode>("wang2");
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
