/*# 导入客户端库
# 初始化客户端库
# 新建节点对象
# spin循环节点
# 关闭客户端库*/

#include "rclcpp/rclcpp.hpp"
#include <memory>
#include <string>

class SingleDogNode:public rclcpp::Node
{
private:
    /* data */
public:
    SingleDogNode(std::string name):Node(name)
   {
       RCLCPP_INFO(this->get_logger(), "大家好，我是单身狗%s.",name.c_str()); 
   }
};


int main(int argc, char ** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<SingleDogNode>("wang2");
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}