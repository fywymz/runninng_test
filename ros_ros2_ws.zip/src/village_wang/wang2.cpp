/*# 导入客户端库
# 初始化客户端库
# 新建节点对象
# spin循环节点
# 关闭客户端库*/

#include "rclcpp/rclcpp.hpp"
#include <memory>

int main(int argc, char ** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<rclcpp::Node>("wang2");
    RCLCPP_INFO(node->get_logger(), "大家好，我是单身狗");
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}